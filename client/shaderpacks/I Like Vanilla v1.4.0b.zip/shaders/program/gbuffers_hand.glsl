in_out vec2 texcoord;
in_out vec2 lmcoord;
in_out vec3 glcolor;
in_out vec3 viewPos;
#if PBR_TYPE == 0
	flat in_out vec2 encodedNormal;
#elif PBR_TYPE == 1
	flat in_out mat3 tbn;
#endif

#if EMISSIVE_TEXTURES_ENABLED == 1
	in_out vec3 glowingColorMin;
	in_out vec3 glowingColorMax;
	in_out float glowingAmount;
#endif



#ifdef FSH

void main() {
	
	vec4 rawColor = texture2D(MAIN_TEXTURE, texcoord) * vec4(glcolor, 1.0);
	if (rawColor.a == 0.0) discard;
	vec4 color = rawColor;
	color.rgb = mix(vec3(getLum(color.rgb)), color.rgb, 1.05);
	
	
	// make yellow colors brighter
	float brightnessIncrease = dot(color.rgb, vec3(0.2, 0.7, 0.1));
	color.rgb *= 1.0 + 0.25 * brightnessIncrease;
	
	
	#if PBR_TYPE == 1
		vec3 normal = texture2D(normals, texcoord).rgb;
		normal.xy -= 0.5;
		normal.xy *= PBR_NORMALS_AMOUNT * 0.75;
		normal.xy += 0.5;
		normal = normalize(normal * 2.0 - 1.0);
		normal = tbn * normal;
		vec2 encodedNormal = encodeNormal(normal);
	#endif
	
	
	float reflectiveness = 0.0;
	float specularness = 0.3;
	
	#if EMISSIVE_TEXTURES_ENABLED == 1
		vec3 hsv = rgbToHsv(rawColor.rgb);
		if (all(greaterThan(hsv, glowingColorMin)) && all(lessThan(hsv, glowingColorMax))) {
			specularness = 254.0 / 255.0;
			reflectiveness = clamp(glowingAmount * 0.5, 0.0, 1.0);
		}
	#endif
	
	
	/* DRAWBUFFERS:02 */
	#if DO_COLOR_CODED_GBUFFERS == 1
		color = vec4(1.0, 0.5, 0.25, 1.0);
	#endif
	color.rgb *= 0.5;
	gl_FragData[0] = vec4(color);
	gl_FragData[1] = vec4(
		pack_2x8(lmcoord),
		pack_2x8(reflectiveness, specularness),
		encodedNormal
	);
	
}

#endif



#ifdef VSH

#define PROJECTION_MATRIX gl_ProjectionMatrix
#include "/utils/projections.glsl"
#include "/lib/lighting/vsh_lighting.glsl"
#if TAA_ENABLED == 1
	#include "/lib/taa_jitter.glsl"
#endif

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	adjustLmcoord(lmcoord);
	glcolor = gl_Color.rgb;
	vec3 normal = gl_NormalMatrix * gl_Normal;
	#if PBR_TYPE == 0
		encodedNormal = encodeNormal(normal);
	#endif
	#if PBR_TYPE == 1
		vec3 tangent = normalize(gl_NormalMatrix * at_tangent.xyz);
		vec3 bitangent = normalize(cross(normal, tangent) * at_tangent.w);
		tbn = mat3(tangent, bitangent, normal);
	#endif
	
	
	// block id stuff
	uint encodedData = uint(currentRenderedItemId);
	encodedData *= uint((encodedData & (1u << 14u)) > 0u && encodedData != 65535u);
	uint materialId = encodedData;
	materialId &= (1u << 10u) - 1u;
	
	
	// get block data
	#define DO_BRIGHTNESS_TWEAKS
	#if EMISSIVE_TEXTURES_ENABLED == 1
		#define GET_GLOWING_COLOR
	#endif
	#include "/generated/blockDatas.glsl"
	
	
	gl_Position = viewToNdc(transform(gl_ModelViewMatrix, gl_Vertex.xyz));
	#if PROJECTION_TYPE == 1
		//gl_Position.xy *= 1.5;
	#endif
	
	
	#if TAA_ENABLED == 1
		doTaaJitter(gl_Position.xy);
	#endif
	
	
	vec3 screenPos = vec3((gl_Position.xy / gl_Position.w) * 0.5 + 0.5, HAND_DEPTH);
	viewPos = screenToView(screenPos);
	doVshLighting(lmcoord, viewPos, normal);
	
}

#endif
