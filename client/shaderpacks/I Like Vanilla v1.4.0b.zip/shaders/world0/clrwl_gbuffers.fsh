#version 140

#define SHADER_CLRWL_GBUFFERS
#define OVERWORLD
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/clrwl_gbuffers.glsl"
